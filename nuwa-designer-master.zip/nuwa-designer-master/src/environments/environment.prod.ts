export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyA6t_RtIPQiCJj9yhaoVu_j9zUflsLQ8ek',
    authDomain: 'nuwa-designer.firebaseapp.com',
    databaseURL: 'https://nuwa-designer.firebaseio.com',
    projectId: 'nuwa-designer',
    storageBucket: 'nuwa-designer.appspot.com',
    messagingSenderId: '894139536621'
  }
};
