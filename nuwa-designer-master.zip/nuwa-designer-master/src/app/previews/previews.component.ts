import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-previews',
  templateUrl: './previews.component.html',
  styleUrls: ['./previews.component.scss']
})
export class PreviewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
