export interface NuwaFormField {
  key: string;
  placeholder: string;
  hint?: string;
  default?: any;
}
