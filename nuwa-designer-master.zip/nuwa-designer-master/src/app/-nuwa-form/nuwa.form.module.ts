import { NgModule } from '@angular/core';

export const NuwaFormComponents = [];

@NgModule({
  imports: [],
  exports: NuwaFormComponents,
  declarations: NuwaFormComponents,
  providers: [],
})
export class NuwaForm { }
