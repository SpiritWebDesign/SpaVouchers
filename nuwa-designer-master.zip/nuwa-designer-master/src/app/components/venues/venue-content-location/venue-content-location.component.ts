import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venue-content-location',
  templateUrl: './venue-content-location.component.html',
  styleUrls: ['./venue-content-location.component.scss']
})
export class VenueContentLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
