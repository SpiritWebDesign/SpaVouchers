import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venue-content-facility',
  templateUrl: './venue-content-facility.component.html',
  styleUrls: ['./venue-content-facility.component.scss']
})
export class VenueContentFacilityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
