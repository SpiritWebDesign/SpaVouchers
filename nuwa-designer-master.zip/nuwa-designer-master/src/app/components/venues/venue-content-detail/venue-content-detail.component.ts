import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venue-content-detail',
  templateUrl: './venue-content-detail.component.html',
  styleUrls: ['./venue-content-detail.component.scss']
})
export class VenueContentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
